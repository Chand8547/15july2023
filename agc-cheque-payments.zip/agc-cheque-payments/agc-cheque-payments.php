<?php
/**
 * Plugin Name: AGC Cheque Payments
 * Description: Custom payment gateway for AGC cheque payments.
 * Version: 1.0.0
 * Author: Your Name
 */

add_action('plugins_loaded', 'agc_cheque_payment_gateway_init');
function agc_cheque_payment_gateway_init()
{
    class AGC_Cheque_Payment_Gateway extends WC_Payment_Gateway
    {
        public function __construct()
        {
            $this->id = 'agc_cheque_payment';
            $this->method_title = 'AGC Cheque Payments';
            $this->method_description = 'Pay by cheque for AGC payments';
            $this->supports = array('products');
            $this->title = 'AGC Cheque Payments';

            $this->init_form_fields();
            $this->init_settings();

            add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
        }

        public function init_form_fields()
        {
            $this->form_fields = array(
                'enabled' => array(
                    'title' => 'Enable/Disable',
                    'type' => 'checkbox',
                    'label' => 'Enable AGC Cheque Payments',
                    'default' => 'no',
                ),
            );
        }

        public function process_payment($order_id)
        {
            $order = wc_get_order($order_id);
            $order->update_status('on-hold', 'AGC awaiting cheque payment');

            return array(
                'result' => 'success',
                'redirect' => $this->get_return_url($order),
            );
        }
    }

    function add_agc_cheque_payment_gateway($methods)
    {
        $methods[] = 'AGC_Cheque_Payment_Gateway';
        return $methods;
    }
    add_filter('woocommerce_payment_gateways', 'add_agc_cheque_payment_gateway');
}



// Change order status and add order notes
function agc_change_order_status($order_id, $status)
{
    if ($status === 'completed') {
        $order = wc_get_order($order_id);
        $order->update_status('on-hold', 'AGC awaiting cheque payment');
    }
}
add_action('woocommerce_order_status_changed', 'agc_change_order_status', 10, 2);


// Customize the thank you page order status
function agc_custom_thankyou_order_status($order_id)
{
    echo '<p class="woocommerce-order-overview__status agc-awaiting-cheque-payment">AGC awaiting cheque payment</p>';
}
add_action('woocommerce_thankyou', 'agc_custom_thankyou_order_status');


// Add order note on marking order as "Complete"
function agc_add_order_note_on_complete($order_id)
{
    $order = wc_get_order($order_id);
    $order->add_order_note('cheque payment completed');
}
add_action('woocommerce_order_status_completed', 'agc_add_order_note_on_complete');
