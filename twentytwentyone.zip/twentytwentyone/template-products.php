<?php
/*
 * Template Name: Products
 */

get_header(); // Include the header file
?>

<div class="product-filter">
    <label for="filter-select">Filter:</label>
    <select id="filter-select">
        <option value="default">Default</option>
        <option value="popular">Show only Popular products</option>
        <option value="featured">Show only Featured products</option>
    </select>
</div>

<div class="product-list">
    <?php
    $args = array(
        'post_type' => 'product',
        'posts_per_page' => 10,
    );

    $products = new WP_Query($args);

    if ($products->have_posts()) {
        while ($products->have_posts()) {
            $products->the_post();
            global $product;
            ?>
            <div class="product">
                <a href="<?php the_permalink(); ?>">
                    <div class="product-image">
                        <?php
                        if (has_post_thumbnail()) {
                            the_post_thumbnail('thumbnail');
                        } else {
                            echo '<img src="' . wc_placeholder_img_src() . '" alt="Placeholder" width="100" height="100" />';
                        }
                        ?>
                    </div>
                    <h2 class="product-title"><?php the_title(); ?></h2>
                </a>
                <div class="product-price"><?php echo $product->get_price_html(); ?></div>
                <a href="<?php echo esc_url($product->add_to_cart_url()); ?>" class="button add-to-cart"><?php echo esc_html($product->add_to_cart_text()); ?></a>
            </div>
            <?php
        }
    } else {
        echo 'No products found.';
    }

    wp_reset_postdata(); // Reset the post data
    ?>
</div>

<?php get_footer(); // Include the footer file ?>
