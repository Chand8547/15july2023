jQuery(document).ready(function($) {
    // AJAX filter handling
    $('#filter-select').on('change', function() {
        var selectedFilter = $(this).val();
        
        $.ajax({
            url: ajax_object.ajaxurl, // Use ajax_object.ajaxurl instead of ajaxurl
            type: 'POST',
            data: {
                action: 'filter_products',
                filter: selectedFilter
            },
            success: function(response) {
                $('.product-list').html(response);
            },
            error: function(errorThrown) {
                console.log(errorThrown);
            }
        });
    });
});


